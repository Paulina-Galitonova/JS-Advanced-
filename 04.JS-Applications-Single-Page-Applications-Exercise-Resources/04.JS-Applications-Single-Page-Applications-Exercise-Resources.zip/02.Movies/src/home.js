import { getAllMovies } from "./dataService.js";
import { getUserId } from "./userHelper.js";
const ul=document.getElementById("movies-list");

export function showHome(){
    document.querySelectorAll("section").forEach(section => section.style.display="none"); //това ще върне array за това използваме директо ForEach 
    document.getElementById("home-page").style.display="block";


    const userId=getUserId();

    if(userId){
        shwAddBtn();
    }
    showAllMovies(userId);
}


function shwAddBtn(){
    document.getElementById("add-movie-button").style.display="block";

}

async function showAllMovies(userId){
    document.getElementById("movie").style.display="block";
const data = await getAllMovies();

data.forEach(movie =>{
    createMovie(movie,userId) 
})
}


function createMovie(data,userId){
const li=document.createElement("li");
li.classList.add("card");
li.classList.add("md-4")
li.innerHTML=`<img src ${data.img}
class="card-img-top"
alt="no img"
/>
<div class ="card-body">
   <h4 class="card-title">${data.title}</h4>
   <a href="/details/${data._id}">

   </a>
   </div>
`;

if(userId){
    const btn=document.createElement("button");
    btn.textContent= "Details";
    btn.dataset.id=data._id;
    li.appendChild(btn);
}
ul.appendChild(li);
}